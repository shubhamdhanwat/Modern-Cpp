#include <iostream>
#include "individualtrip.h"
#include "sharedtrip.h"

int main()
{

    sharedTrip obj1("100", "SHAM", 15, 2, COMFORT, 20);
    std::cout << obj1.calculateFare();

    return 0;
}